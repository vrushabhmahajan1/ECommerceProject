package com.exaple.heap;

public class HeapFull {
	public static void main(String[] args) {
		try {
			int[] i = new int[1000*100000];
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
	}
}
