package com.example.nullpointerexception;

public class NullPointerExcepExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=null;
		if(s.equals("Megha"))
		{
			System.out.println(s);
		}

	}
}
