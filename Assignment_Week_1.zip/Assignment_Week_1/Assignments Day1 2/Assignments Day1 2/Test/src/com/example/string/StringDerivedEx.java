package com.example.string;

public class StringDerivedEx extends String{
	/* Here it is giving error...
	  String is a Final class.
	  Hence,Final class cannot be derived ...*/
}
